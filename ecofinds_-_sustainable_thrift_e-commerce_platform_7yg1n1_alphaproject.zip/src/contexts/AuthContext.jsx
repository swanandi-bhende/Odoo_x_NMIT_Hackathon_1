import React, { createContext, useContext, useState, useEffect } from 'react';
import db from '../data/mockDB';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = () => {
    try {
      const loggedInUserId = localStorage.getItem('ecofinds_user_id');
      if (loggedInUserId) {
        const currentUser = db.users.findById(parseInt(loggedInUserId));
        if (currentUser) {
          const { password, ...userToSet } = currentUser;
          setUser(userToSet);
        }
      }
    } catch (error) {
      console.error("Failed to check auth status:", error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (credentials) => {
    const { email, password } = credentials;
    const foundUser = db.users.findByEmail(email);

    if (foundUser && foundUser.password === password) {
      const { password: userPassword, ...userToSet } = foundUser;
      setUser(userToSet);
      localStorage.setItem('ecofinds_user_id', userToSet.id);
      return { user: userToSet };
    } else {
      throw { message: 'Invalid credentials. Please try again.' };
    }
  };

  const signup = async (userData) => {
    const { email, password } = userData;
    const existingUser = db.users.findByEmail(email);

    if (existingUser) {
      throw { message: 'User with this email already exists.' };
    }

    const newUser = db.users.create(userData);
    
    // Automatically log in the new user
    await login({ email, password });

    const { password: userPassword, ...userToReturn } = newUser;
    return { user: userToReturn };
  };

  const logout = async () => {
    setUser(null);
    localStorage.removeItem('ecofinds_user_id');
  };

  const updateUser = async (profileData) => {
    if (!user) throw new Error("No user logged in");
    const updatedUser = db.users.update(user.id, profileData);
    const { password, ...userToSet } = updatedUser;
    setUser(userToSet);
    return userToSet;
  };

  const value = {
    user,
    login,
    signup,
    logout,
    updateUser,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
