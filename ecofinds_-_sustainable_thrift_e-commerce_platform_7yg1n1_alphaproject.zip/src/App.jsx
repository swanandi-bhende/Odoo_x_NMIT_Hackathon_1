import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { SidebarProvider } from './contexts/SidebarContext';
import AppLayout from './components/Layout/AppLayout';
import Dashboard from './pages/Dashboard';
import Browsing from './pages/Browsing';
import Profile from './pages/Profile';
import Cart from './pages/Cart';
import Login from './pages/Login';
import Signup from './pages/Signup';
import ProtectedRoute from './components/ProtectedRoute';
import EcoBot from './components/EcoBot';

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <SidebarProvider>
          <Router>
            <div className="min-h-screen bg-neutral-bg">
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                
                <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/browse" element={<Browsing />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/cart" element={<Cart />} />
                  {/* Add other protected routes here */}
                </Route>

                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
              <EcoBot />
            </div>
          </Router>
        </SidebarProvider>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
