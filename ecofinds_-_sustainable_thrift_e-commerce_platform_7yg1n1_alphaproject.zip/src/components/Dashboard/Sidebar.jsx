import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  Heart, 
  MessageCircle, 
  Search, 
  Tag, 
  Leaf, 
  HelpCircle, 
  Settings,
  X
} from 'lucide-react';

const Sidebar = ({ isOpen, onClose }) => {
  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', active: true },
    { icon: Package, label: 'My Listings' },
    { icon: ShoppingBag, label: 'Orders' },
    { icon: Heart, label: 'Wishlist' },
    { icon: MessageCircle, label: 'Messages' },
    { icon: Search, label: 'Saved Searches' },
    { icon: Tag, label: 'Coupons & Offers' },
    { icon: Leaf, label: 'Sustainability' },
    { icon: HelpCircle, label: 'Support' },
    { icon: Settings, label: 'Settings' }
  ];

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.div
        initial={{ x: '-100%' }}
        animate={{ x: isOpen ? 0 : '-100%' }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="lg:translate-x-0 lg:static fixed left-0 top-0 h-full w-64 bg-white border-r border-gray-200 z-50 lg:z-auto"
      >
        <div className="flex items-center justify-between p-4 lg:hidden border-b border-gray-200">
          <span className="font-semibold text-lg">Menu</span>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-card"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item, index) => (
            <motion.button
              key={item.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-card text-left transition-colors ${
                item.active 
                  ? 'bg-eco-green text-white' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </nav>
      </motion.div>
    </>
  );
};

export default Sidebar;
